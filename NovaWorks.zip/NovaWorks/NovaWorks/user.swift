import Foundation
import SwiftData

@Model
public final class User {
    @Attribute(.unique) public var id: String
    public var name: String
    public var email: String
    public var role: String // 'ADMIN', 'MANAGER', or 'AGENT'
    public var specialization: String
    public var skills: [String]
    public var password: String // 'Demo123!'

    public init(
        id: String,
        name: String,
        email: String,
        role: String,
        specialization: String,
        skills: [String] = [],
        password: String = "Demo123!"
    ) {
        self.id = id
        self.name = name
        self.email = email
        self.role = role
        self.specialization = specialization
        self.skills = skills
        self.password = password
    }
}
