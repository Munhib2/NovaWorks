//
//  AdminDashboardView.swift
//  NovaWorks
//

import SwiftUI
import SwiftData

struct AdminDashboardView: View {
    @EnvironmentObject private var authService: AuthService
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \User.id) private var allUsers: [User]
    @Query private var allProjects: [Project]
    @Query private var allTasks: [Task]
    
    @State private var selectedRoleFilter: String = "ALL"
    
    var filteredUsers: [User] {
        if selectedRoleFilter == "ALL" {
            return allUsers
        }
        return allUsers.filter { $0.role == selectedRoleFilter }
    }
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    // Admin Profile Banner
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("System Administration")
                                    .font(.caption)
                                    .fontWeight(.bold)
                                    .foregroundStyle(.red)
                                    .textCase(.uppercase)
                                
                                Text(authService.currentUser?.name ?? "Admin")
                                    .font(.title2)
                                    .fontWeight(.bold)
                            }
                            
                            Spacer()
                            
                            Button(action: { authService.logout() }) {
                                HStack(spacing: 4) {
                                    Image(systemName: "rectangle.portrait.and.arrow.right")
                                    Text("Logout")
                                }
                                .font(.caption)
                                .fontWeight(.semibold)
                                .foregroundStyle(.red)
                                .padding(.horizontal, 12)
                                .padding(.vertical, 6)
                                .background(Color.red.opacity(0.1))
                                .clipShape(Capsule())
                            }
                        }
                        
                        Text(authService.currentUser?.email ?? "admin@novaworks.example")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color(.secondarySystemBackground))
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    
                    // Quick Stats Row
                    HStack(spacing: 12) {
                        statCard(title: "Total Users", value: "\(allUsers.count)", icon: "person.3.fill", tint: .purple)
                        statCard(title: "Projects", value: "\(allProjects.count)", icon: "folder.fill", tint: .blue)
                        statCard(title: "Tasks", value: "\(allTasks.count)", icon: "checklist", tint: .green)
                    }
                    
                    // Role Filter Segmented Control
                    Picker("Filter Role", selection: $selectedRoleFilter) {
                        Text("All (\(allUsers.count))").tag("ALL")
                        Text("Admins").tag("ADMIN")
                        Text("Managers").tag("MANAGER")
                        Text("Agents").tag("AGENT")
                    }
                    .pickerStyle(.segmented)
                    
                    // Users List Section
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Team Members Directory")
                            .font(.headline)
                        
                        LazyVStack(spacing: 10) {
                            ForEach(filteredUsers) { user in
                                UserCardView(user: user)
                            }
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("Admin Dashboard")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
    
    private func statCard(title: String, value: String, icon: String, tint: Color) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Image(systemName: icon)
                    .foregroundStyle(tint)
                Spacer()
                Text(value)
                    .font(.title3)
                    .fontWeight(.bold)
            }
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

private struct UserCardView: View {
    let user: User
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    HStack(spacing: 6) {
                        Text(user.name)
                            .font(.headline)
                        Text("[\(user.id)]")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Text(user.email)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                
                Spacer()
                
                Text(user.role)
                    .font(.caption2)
                    .fontWeight(.bold)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 3)
                    .background(roleColor(for: user.role).opacity(0.15))
                    .foregroundStyle(roleColor(for: user.role))
                    .clipShape(Capsule())
            }
            
            Text(user.specialization)
                .font(.caption)
                .foregroundStyle(.primary)
            
            if !user.skills.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 4) {
                        ForEach(user.skills, id: \.self) { skill in
                            Text(skill)
                                .font(.system(size: 10, weight: .medium))
                                .padding(.horizontal, 6)
                                .padding(.vertical, 2)
                                .background(Color(.tertiarySystemBackground))
                                .clipShape(RoundedRectangle(cornerRadius: 4))
                        }
                    }
                }
            }
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
    
    private func roleColor(for role: String) -> Color {
        switch role {
        case "ADMIN": return .red
        case "MANAGER": return .blue
        case "AGENT": return .green
        default: return .gray
        }
    }
}
