//
//  ManagerDashboardView.swift
//  NovaWorks
//

import SwiftUI
import SwiftData

struct ManagerDashboardView: View {
    @EnvironmentObject private var authService: AuthService
    @Environment(\.modelContext) private var modelContext
    @Query private var allProjects: [Project]
    @Query private var allTasks: [Task]
    
    // Filter projects assigned to this specific manager
    var myProjects: [Project] {
        guard let managerId = authService.currentUserId else { return [] }
        return allProjects.filter { $0.managerId == managerId }
    }
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    // Profile Banner
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Project Manager Workspace")
                                    .font(.caption)
                                    .fontWeight(.bold)
                                    .foregroundStyle(.blue)
                                    .textCase(.uppercase)
                                
                                Text(authService.currentUser?.name ?? "Manager")
                                    .font(.title2)
                                    .fontWeight(.bold)
                            }
                            
                            Spacer()
                            
                            Button(action: { authService.logout() }) {
                                HStack(spacing: 4) {
                                    Image(systemName: "rectangle.portrait.and.arrow.right")
                                    Text("Logout")
                                }
                                .font(.caption)
                                .fontWeight(.semibold)
                                .foregroundStyle(.red)
                                .padding(.horizontal, 12)
                                .padding(.vertical, 6)
                                .background(Color.red.opacity(0.1))
                                .clipShape(Capsule())
                            }
                        }
                        
                        HStack(spacing: 8) {
                            Text(authService.currentUser?.id ?? "PM01")
                                .font(.caption)
                                .fontWeight(.semibold)
                                .padding(.horizontal, 6)
                                .padding(.vertical, 2)
                                .background(Color.blue.opacity(0.15))
                                .foregroundStyle(.blue)
                                .clipShape(RoundedRectangle(cornerRadius: 4))
                            
                            Text(authService.currentUser?.specialization ?? "Web PM")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color(.secondarySystemBackground))
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    
                    // Projects Section Header
                    HStack {
                        Text("Overseen Projects")
                            .font(.headline)
                        Spacer()
                        Text("\(myProjects.count) Active")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    
                    if myProjects.isEmpty {
                        VStack(spacing: 12) {
                            Image(systemName: "folder.badge.plus")
                                .font(.system(size: 40))
                                .foregroundStyle(.blue.opacity(0.8))
                            
                            Text("No Projects Assigned")
                                .font(.headline)
                            
                            Text("Generate a demo project to explore the manager dashboard capabilities.")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .multilineTextAlignment(.center)
                            
                            Button(action: seedSampleProject) {
                                Text("Create Sample Project")
                                    .font(.caption)
                                    .fontWeight(.semibold)
                                    .foregroundStyle(.white)
                                    .padding(.horizontal, 14)
                                    .padding(.vertical, 8)
                                    .background(Color.blue)
                                    .clipShape(Capsule())
                            }
                        }
                        .padding(30)
                        .frame(maxWidth: .infinity)
                        .background(Color(.secondarySystemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                    } else {
                        LazyVStack(spacing: 12) {
                            ForEach(myProjects) { project in
                                ProjectCardRow(project: project, allTasks: allTasks)
                            }
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("Manager View")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
    
    private func seedSampleProject() {
        guard let managerId = authService.currentUserId else { return }
        let sample = Project(
            id: "PROJ-\(Int.random(in: 100...999))",
            name: "\(authService.currentUser?.specialization ?? "Engineering") Platform",
            clientName: "Acme Enterprises",
            projectDescription: "Core deliverables, pipeline architecture, and cross-team execution plan.",
            managerId: managerId,
            deadline: "2026-12-31"
        )
        modelContext.insert(sample)
        try? modelContext.save()
    }
}

private struct ProjectCardRow: View {
    let project: Project
    let allTasks: [Task]
    
    var tasksForProject: [Task] {
        allTasks.filter { $0.projectId == project.id }
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(project.name)
                    .font(.headline)
                Spacer()
                Text(project.id)
                    .font(.caption2)
                    .fontWeight(.bold)
                    .padding(.horizontal, 6)
                    .padding(.vertical, 2)
                    .background(Color(.tertiarySystemBackground))
                    .clipShape(RoundedRectangle(cornerRadius: 4))
            }
            
            Text("Client: \(project.clientName)")
                .font(.caption)
                .foregroundStyle(.secondary)
            
            Text(project.projectDescription)
                .font(.caption)
                .foregroundStyle(.primary)
                .lineLimit(2)
            
            Divider()
            
            HStack {
                Label(project.deadline, systemImage: "calendar")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                
                Spacer()
                
                Label("\(tasksForProject.count) Tasks", systemImage: "checklist")
                    .font(.caption2)
                    .foregroundStyle(.blue)
            }
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}
