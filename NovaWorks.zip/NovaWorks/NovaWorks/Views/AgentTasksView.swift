//
//  AgentTasksView.swift
//  NovaWorks
//

import SwiftUI
import SwiftData

struct AgentTasksView: View {
    @EnvironmentObject private var authService: AuthService
    @Environment(\.modelContext) private var modelContext
    @Query private var allTasks: [Task]
    
    // Filter tasks assigned to currently logged-in Agent
    var myTasks: [Task] {
        guard let currentId = authService.currentUserId else { return [] }
        return allTasks.filter { $0.assigneeId == currentId }
    }
    
    var totalEstimatedHours: Int {
        myTasks.reduce(0) { $0 + $1.estimatedHours }
    }
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    // Agent Profile Card
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Developer Agent Workspace")
                                    .font(.caption)
                                    .fontWeight(.bold)
                                    .foregroundStyle(.green)
                                    .textCase(.uppercase)
                                
                                Text(authService.currentUser?.name ?? "Agent")
                                    .font(.title2)
                                    .fontWeight(.bold)
                            }
                            
                            Spacer()
                            
                            Button(action: { authService.logout() }) {
                                HStack(spacing: 4) {
                                    Image(systemName: "rectangle.portrait.and.arrow.right")
                                    Text("Logout")
                                }
                                .font(.caption)
                                .fontWeight(.semibold)
                                .foregroundStyle(.red)
                                .padding(.horizontal, 12)
                                .padding(.vertical, 6)
                                .background(Color.red.opacity(0.1))
                                .clipShape(Capsule())
                            }
                        }
                        
                        HStack(spacing: 8) {
                            Text(authService.currentUser?.id ?? "DEV01")
                                .font(.caption)
                                .fontWeight(.semibold)
                                .padding(.horizontal, 6)
                                .padding(.vertical, 2)
                                .background(Color.green.opacity(0.15))
                                .foregroundStyle(.green)
                                .clipShape(RoundedRectangle(cornerRadius: 4))
                            
                            Text(authService.currentUser?.specialization ?? "Full-Stack")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                        
                        if let skills = authService.currentUser?.skills, !skills.isEmpty {
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 4) {
                                    ForEach(skills, id: \.self) { skill in
                                        Text(skill)
                                            .font(.system(size: 10, weight: .medium))
                                            .padding(.horizontal, 6)
                                            .padding(.vertical, 2)
                                            .background(Color(.tertiarySystemBackground))
                                            .clipShape(RoundedRectangle(cornerRadius: 4))
                                    }
                                }
                            }
                        }
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color(.secondarySystemBackground))
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    
                    // Task Summary Cards
                    HStack(spacing: 12) {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("\(myTasks.count)")
                                .font(.title2)
                                .fontWeight(.bold)
                            Text("Assigned Tasks")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color(.secondarySystemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        
                        VStack(alignment: .leading, spacing: 6) {
                            Text("\(totalEstimatedHours)h")
                                .font(.title2)
                                .fontWeight(.bold)
                                .foregroundStyle(.green)
                            Text("Total Estimated Hours")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color(.secondarySystemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                    }
                    
                    // Tasks Section
                    HStack {
                        Text("My Assigned Tasks")
                            .font(.headline)
                        Spacer()
                    }
                    
                    if myTasks.isEmpty {
                        VStack(spacing: 12) {
                            Image(systemName: "checkmark.circle")
                                .font(.system(size: 44))
                                .foregroundStyle(.green.opacity(0.8))
                            
                            Text("All Caught Up")
                                .font(.headline)
                            
                            Text("No pending tasks assigned to your account. You can create a test task below.")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .multilineTextAlignment(.center)
                            
                            Button(action: seedSampleTask) {
                                Text("Generate Sample Task")
                                    .font(.caption)
                                    .fontWeight(.semibold)
                                    .foregroundStyle(.white)
                                    .padding(.horizontal, 14)
                                    .padding(.vertical, 8)
                                    .background(Color.green)
                                    .clipShape(Capsule())
                            }
                        }
                        .padding(30)
                        .frame(maxWidth: .infinity)
                        .background(Color(.secondarySystemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                    } else {
                        LazyVStack(spacing: 12) {
                            ForEach(myTasks) { task in
                                TaskCardRow(task: task)
                            }
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("My Tasks")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
    
    private func seedSampleTask() {
        guard let currentId = authService.currentUserId else { return }
        let sampleTask = Task(
            id: "TASK-\(Int.random(in: 100...999))",
            projectId: "PROJ-101",
            title: "Implement \(authService.currentUser?.specialization ?? "Core") Workflow",
            taskDescription: "Design, code, test, and integrate the user-facing interface and backing service.",
            assigneeId: currentId,
            deadline: "2026-11-30",
            estimatedHours: 6
        )
        modelContext.insert(sampleTask)
        try? modelContext.save()
    }
}

private struct TaskCardRow: View {
    let task: Task
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(task.title)
                    .font(.headline)
                Spacer()
                Text("\(task.estimatedHours)h")
                    .font(.caption)
                    .fontWeight(.bold)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 2)
                    .background(Color.green.opacity(0.15))
                    .foregroundStyle(.green)
                    .clipShape(Capsule())
            }
            
            Text(task.taskDescription)
                .font(.caption)
                .foregroundStyle(.secondary)
            
            Divider()
            
            HStack {
                Label(task.projectId, systemImage: "folder")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                
                Spacer()
                
                Label(task.deadline, systemImage: "clock")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}
