import Foundation
import SwiftData

@Model
public final class Task {
    @Attribute(.unique) public var id: String
    public var projectId: String
    public var title: String
    public var taskDescription: String
    public var assigneeId: String
    public var deadline: String
    public var estimatedHours: Int

    public init(
        id: String,
        projectId: String,
        title: String,
        taskDescription: String,
        assigneeId: String,
        deadline: String,
        estimatedHours: Int
    ) {
        self.id = id
        self.projectId = projectId
        self.title = title
        self.taskDescription = taskDescription
        self.assigneeId = assigneeId
        self.deadline = deadline
        self.estimatedHours = estimatedHours
    }
}
