import Foundation
import SwiftData

@Model
public final class Project {
    @Attribute(.unique) public var id: String
    public var name: String
    public var clientName: String
    public var projectDescription: String
    public var managerId: String
    public var deadline: String

    public init(
        id: String,
        name: String,
        clientName: String,
        projectDescription: String,
        managerId: String,
        deadline: String
    ) {
        self.id = id
        self.name = name
        self.clientName = clientName
        self.projectDescription = projectDescription
        self.managerId = managerId
        self.deadline = deadline
    }
}
