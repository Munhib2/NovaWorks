import SwiftUI
import SwiftData

@main
struct NovaWorksApp: App {
    let container: ModelContainer
    @StateObject private var authService = AuthService()

    init() {
        self.container = NovaWorksSchema.makeContainer()
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(authService)
                .onAppear {
                    seedDemoUsers(modelContext: container.mainContext)
                }
        }
        .modelContainer(container)
    }
}
