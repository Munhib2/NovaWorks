import SwiftUI
import SwiftData

struct LoginView: View {
    @Environment(\.modelContext) private var modelContext
    @EnvironmentObject private var authService: AuthService
    
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var showPassword: Bool = false
    @State private var showErrorAlert: Bool = false
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 24) {
                Spacer()
                
                VStack(spacing: 8) {
                    Image(systemName: "cube.box.fill")
                        .font(.system(size: 60))
                        .foregroundStyle(.tint)
                    Text("NovaWorks")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                    Text("AI-Driven Team & Task Management")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                
                VStack(spacing: 16) {
                    TextField("Email Address", text: $email)
                        .keyboardType(.emailAddress)
                        .autocapitalization(.none)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(10)
                    
                    HStack {
                        if showPassword {
                            TextField("Password", text: $password)
                                .autocapitalization(.none)
                        } else {
                            SecureField("Password", text: $password)
                        }
                        
                        Button(action: { showPassword.toggle() }) {
                            Image(systemName: showPassword ? "eye.slash.fill" : "eye.fill")
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(10)
                }
                .padding(.horizontal)
                
                Button(action: {
                    let success = authService.login(email: email, password: password, modelContext: modelContext)
                    if !success {
                        showErrorAlert = true
                    }
                }) {
                    Text("Login")
                        .fontWeight(.semibold)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundStyle(.white)
                        .cornerRadius(10)
                }
                .padding(.horizontal)
                
                // Quick Demo Chips
                VStack(spacing: 8) {
                    Text("Quick Demo Fill:")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    
                    HStack(spacing: 12) {
                        Button("Admin") { email = "admin@novaworks.example"; password = "Demo123!" }
                        Button("Manager") { email = "ayesha@novaworks.example"; password = "Demo123!" }
                        Button("Agent") { email = "ali@novaworks.example"; password = "Demo123!" }
                    }
                    .font(.caption2)
                    .buttonStyle(.bordered)
                }
                
                Spacer()
            }
            .padding()
            .navigationDestination(isPresented: $authService.isAuthenticated) {
                roleDestinationView
            }
            .alert("Invalid Credentials", isPresented: $showErrorAlert) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(authService.errorMessage ?? "Please check credentials.")
            }
        }
    }
    
    @ViewBuilder
    private var roleDestinationView: some View {
        switch authService.currentUserRole {
        case "ADMIN":
            Text("Admin Dashboard (Next Step)")
        case "MANAGER":
            Text("Manager Dashboard (Next Step)")
        case "AGENT":
            Text("Agent Tasks View (Next Step)")
        default:
            Text("Unknown Role")
        }
    }
}
