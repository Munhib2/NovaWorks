import SwiftUI
import SwiftData

// MARK: - Models for UI Rendering

struct WorkTask: Identifiable, Hashable {
    let id: String
    let projectID: String
    var title: String
    var description: String
    var assigneeID: String
    var deadline: String
    var hours: Int
    var status: String
}

struct WorkProject: Identifiable, Hashable {
    let id: String
    var name: String
    var client: String
    var description: String
    var managerID: String
    var deadline: String
}

// MARK: - Theme

enum NovaTheme {
    static let background = Color(red: 0.025, green: 0.055, blue: 0.12)
    static let sidebar = Color(red: 0.035, green: 0.075, blue: 0.15)
    static let panel = Color(red: 0.055, green: 0.105, blue: 0.19).opacity(0.85)
    static let blue = Color(red: 0.20, green: 0.68, blue: 0.98)
    static let cyan = Color(red: 0.28, green: 0.83, blue: 0.96)
    static let lavenderBlue = Color(red: 0.48, green: 0.65, blue: 0.95)
    static let muted = Color(red: 0.56, green: 0.65, blue: 0.77)
    static let border = Color.white.opacity(0.12)
}

// MARK: - Root Content View (Handles Login vs Dashboard Routing)

struct ContentView: View {
    @EnvironmentObject private var authService: AuthService

    var body: some View {
        Group {
            if authService.isAuthenticated, let user = authService.currentUser {
                DashboardView(currentUser: user)
            } else {
                LoginView()
            }
        }
    }
}

// MARK: - Authenticated Dashboard View (Role-based, Clean, No Role Switcher)

struct DashboardView: View {
    let currentUser: User

    @Environment(\.modelContext) private var modelContext
    @EnvironmentObject private var authService: AuthService
    @Query private var swiftProjects: [Project]
    @Query private var swiftTasks: [Task]
    @Query private var allUsers: [User]

    @State private var selectedTab = 0 // 0: Home, 1: Projects, 2: Tasks, 3: Directory
    @State private var selectedProject: WorkProject?
    @State private var selectedTask: WorkTask?
    @State private var showingTranscript = false
    @State private var transcript = ""
    @State private var isProcessing = false
    @State private var toast: String?

    private var projects: [WorkProject] {
        swiftProjects.map { p in
            WorkProject(id: p.id, name: p.name, client: p.clientName, description: p.projectDescription, managerID: p.managerId, deadline: p.deadline)
        }
    }

    private var tasks: [WorkTask] {
        swiftTasks.map { t in
            WorkTask(id: t.id, projectID: t.projectId, title: t.title, description: t.taskDescription, assigneeID: t.assigneeId, deadline: t.deadline, hours: t.estimatedHours, status: "In Progress")
        }
    }

    private var visibleProjects: [WorkProject] {
        switch currentUser.role {
        case "ADMIN":
            return projects
        case "MANAGER":
            return projects.filter { $0.managerID == currentUser.id }
        case "AGENT":
            let projectIDs = Set(tasks.filter { $0.assigneeID == currentUser.id }.map(\.projectID))
            return projects.filter { projectIDs.contains($0.id) }
        default:
            return []
        }
    }

    private var visibleTasks: [WorkTask] {
        switch currentUser.role {
        case "ADMIN":
            return tasks
        case "MANAGER":
            let ids = Set(visibleProjects.map(\.id))
            return tasks.filter { ids.contains($0.projectID) }
        case "AGENT":
            return tasks.filter { $0.assigneeID == currentUser.id }
        default:
            return []
        }
    }

    var body: some View {
        ZStack {
            background
            
            VStack(spacing: 0) {
                iosTopBar
                
                TabView(selection: $selectedTab) {
                    dashboardPage.tag(0)
                    projectsPage.tag(1)
                    tasksPage.tag(2)
                    directoryPage.tag(3)
                }
                .tabViewStyle(.page(indexDisplayMode: .never))
                
                iosBottomTabBar
            }

            if let toast {
                VStack {
                    Spacer()
                    Text(toast)
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 18).padding(.vertical, 12)
                        .background(.ultraThinMaterial, in: Capsule())
                        .overlay(Capsule().stroke(NovaTheme.blue.opacity(0.5), lineWidth: 1))
                        .padding(.bottom, 90)
                }
                .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .sheet(isPresented: $showingTranscript) {
            TranscriptSheet(transcript: $transcript, isProcessing: $isProcessing) {
                showingTranscript = false
                toast = "AI Plan generated successfully!"
            }
        }
        .sheet(item: $selectedProject) { project in
            ProjectDetailSheet(project: project, tasks: tasksFor(project), allUsers: allUsers, currentUser: currentUser) { task in
                selectedTask = task
            }
        }
        .sheet(item: $selectedTask) { task in
            TaskDetailSheet(task: task, project: projects.first(where: { $0.id == task.projectID }), allUsers: allUsers)
        }
        .onChange(of: toast) { value in
            guard value != nil else { return }
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                withAnimation { toast = nil }
            }
        }
    }

    private var background: some View {
        ZStack {
            LinearGradient(colors: [NovaTheme.background, Color(red: 0.035, green: 0.09, blue: 0.17), NovaTheme.background], startPoint: .topLeading, endPoint: .bottomTrailing)
            Circle().fill(NovaTheme.blue.opacity(0.08)).frame(width: 320).blur(radius: 80).offset(x: 150, y: -200)
        }.ignoresSafeArea()
    }

    private var iosTopBar: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text("NovaWorks").font(.system(size: 16, weight: .bold)).foregroundStyle(.white)
                Text("\(currentUser.name) (\(currentUser.role))").font(.system(size: 10)).foregroundStyle(NovaTheme.cyan)
            }
            Spacer()
            Button(action: {
                authService.logout()
            }) {
                Label("Logout", systemImage: "rectangle.portrait.and.arrow.right")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(.red)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(.red.opacity(0.12), in: Capsule())
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(NovaTheme.sidebar.opacity(0.95))
        .overlay(alignment: .bottom) { Rectangle().fill(NovaTheme.border).frame(height: 1) }
    }

    private var iosBottomTabBar: some View {
        HStack {
            tabButton(title: "Home", icon: "square.grid.2x2", index: 0)
            tabButton(title: "Projects", icon: "folder", index: 1)
            tabButton(title: "Tasks", icon: "checkmark.circle", index: 2)
            tabButton(title: "Team", icon: "person.2", index: 3)
        }
        .padding(.vertical, 8)
        .background(NovaTheme.sidebar.opacity(0.98))
        .overlay(alignment: .top) { Rectangle().fill(NovaTheme.border).frame(height: 1) }
    }

    private func tabButton(title: String, icon: String, index: Int) -> some View {
        Button {
            selectedTab = index
        } label: {
            VStack(spacing: 4) {
                Image(systemName: icon)
                    .font(.system(size: 18, weight: selectedTab == index ? .bold : .regular))
                Text(title)
                    .font(.system(size: 10, weight: selectedTab == index ? .semibold : .regular))
            }
            .foregroundStyle(selectedTab == index ? NovaTheme.cyan : NovaTheme.muted)
            .frame(maxWidth: .infinity)
        }
    }

    private var dashboardPage: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Welcome, \(currentUser.name)").font(.system(size: 22, weight: .bold)).foregroundStyle(.white)
                    Text(subtitle).font(.system(size: 12)).foregroundStyle(NovaTheme.muted)
                }
                .padding(.top, 10)

                if currentUser.role == "ADMIN" {
                    Button { showingTranscript = true } label: {
                        Label("Create from Transcript", systemImage: "sparkles")
                            .font(.system(size: 13, weight: .semibold))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                    }
                    .buttonStyle(BlueButtonStyle())
                }

                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                    MetricCard(title: "PROJECTS", value: "\(visibleProjects.count)", caption: "Accessible workflow", icon: "folder", tint: NovaTheme.blue)
                    MetricCard(title: "TASKS", value: "\(visibleTasks.count)", caption: "Assigned items", icon: "checklist", tint: NovaTheme.cyan)
                }

                sectionHeader("Active Projects") { selectedTab = 1 }
                
                ForEach(visibleProjects.prefix(3)) { project in
                    ProjectRow(project: project, manager: person(project.managerID), taskCount: tasksFor(project).count) {
                        selectedProject = project
                    }
                }
            }
            .padding(16)
        }
    }

    private var projectsPage: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                pageTitle("Projects", subtitle: "Workflows assigned to your account")
                ForEach(visibleProjects) { project in
                    ProjectRow(project: project, manager: person(project.managerID), taskCount: tasksFor(project).count) {
                        selectedProject = project
                    }
                }
            }
            .padding(16)
        }
    }

    private var tasksPage: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                pageTitle("Tasks", subtitle: "Your action items")
                ForEach(visibleTasks) { task in
                    TaskRow(task: task, project: projects.first(where: { $0.id == task.projectID }), assignee: person(task.assigneeID)) {
                        selectedTask = task
                    }
                }
            }
            .padding(16)
        }
    }

    private var directoryPage: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                pageTitle("Team Directory", subtitle: "NovaWorks personnel")
                
                VStack(spacing: 10) {
                    ForEach(allUsers.filter { $0.role != "ADMIN" }) { member in
                        GlassPanel {
                            HStack(spacing: 12) {
                                Avatar(initials: String(member.name.prefix(2)).uppercased(), size: 32)
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(member.name).font(.system(size: 13, weight: .semibold)).foregroundStyle(.white)
                                    Text(member.specialization).font(.system(size: 11)).foregroundStyle(NovaTheme.muted)
                                }
                                Spacer()
                                StatusPill(text: member.role, color: member.role == "MANAGER" ? NovaTheme.lavenderBlue : NovaTheme.cyan)
                            }
                        }
                    }
                }
            }
            .padding(16)
        }
    }

    private var subtitle: String {
        switch currentUser.role {
        case "ADMIN": return "System Administrator · Full company overview & AI transcript"
        case "MANAGER": return "Project Manager · Managing your assigned client deliveries"
        case "AGENT": return "Developer Agent · Your active tasks and milestones"
        default: return "Workspace"
        }
    }

    private func sectionHeader(_ title: String, action: @escaping () -> Void) -> some View {
        HStack {
            Text(title).font(.system(size: 15, weight: .semibold)).foregroundStyle(.white)
            Spacer()
            Button("View All", action: action).font(.system(size: 11, weight: .medium)).foregroundStyle(NovaTheme.cyan)
        }.padding(.top, 6)
    }

    private func pageTitle(_ title: String, subtitle: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title).font(.system(size: 22, weight: .bold)).foregroundStyle(.white)
            Text(subtitle).font(.system(size: 12)).foregroundStyle(NovaTheme.muted)
        }.padding(.top, 10)
    }

    private func person(_ id: String) -> User? { allUsers.first(where: { $0.id == id }) }
    
    private func tasksFor(_ project: WorkProject) -> [WorkTask] {
        let all = tasks.filter { $0.projectID == project.id }
        if currentUser.role == "AGENT" { return all.filter { $0.assigneeID == currentUser.id } }
        return all
    }
}

// MARK: - Reusable UI Components

struct GlassPanel<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        VStack(alignment: .leading, spacing: 8) { content }
            .padding(14)
            .background {
                RoundedRectangle(cornerRadius: 14)
                    .fill(.ultraThinMaterial)
                    .environment(\.colorScheme, .dark)
                    .overlay(RoundedRectangle(cornerRadius: 14).fill(NovaTheme.panel))
            }
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(NovaTheme.border, lineWidth: 1))
    }
}

struct MetricCard: View {
    let title: String
    let value: String
    let caption: String
    let icon: String
    let tint: Color
    var body: some View {
        GlassPanel {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 6) {
                    Text(title).font(.system(size: 9, weight: .bold)).tracking(0.6).foregroundStyle(NovaTheme.muted)
                    Text(value).font(.system(size: 22, weight: .bold, design: .rounded)).foregroundStyle(.white)
                    Text(caption).font(.system(size: 10)).foregroundStyle(NovaTheme.muted)
                }
                Spacer()
                Image(systemName: icon).font(.system(size: 14, weight: .semibold)).foregroundStyle(tint)
                    .frame(width: 30, height: 30).background(tint.opacity(0.12), in: RoundedRectangle(cornerRadius: 8))
            }
        }
    }
}

struct ProjectRow: View {
    let project: WorkProject
    let manager: User?
    let taskCount: Int
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            GlassPanel {
                HStack(spacing: 12) {
                    Image(systemName: "folder.fill").font(.system(size: 15)).foregroundStyle(NovaTheme.cyan)
                        .frame(width: 34, height: 34).background(NovaTheme.blue.opacity(0.13), in: RoundedRectangle(cornerRadius: 8))
                    VStack(alignment: .leading, spacing: 4) {
                        Text(project.name).font(.system(size: 13, weight: .semibold)).foregroundStyle(.white)
                        Text("\(project.client) · Manager: \(manager?.name ?? "—")").font(.system(size: 10)).foregroundStyle(NovaTheme.muted)
                    }
                    Spacer()
                    VStack(alignment: .trailing, spacing: 4) {
                        StatusPill(text: "ACTIVE", color: NovaTheme.cyan)
                        Text("\(taskCount) tasks").font(.system(size: 9)).foregroundStyle(NovaTheme.muted)
                    }
                }
            }
        }.buttonStyle(.plain)
    }
}

struct TaskRow: View {
    let task: WorkTask
    let project: WorkProject?
    let assignee: User?
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            GlassPanel {
                HStack(spacing: 10) {
                    Image(systemName: "checkmark.circle").font(.system(size: 15)).foregroundStyle(NovaTheme.cyan)
                    VStack(alignment: .leading, spacing: 4) {
                        Text(task.title).font(.system(size: 12, weight: .semibold)).foregroundStyle(.white)
                        Text("\(project?.name ?? "Project") · Assigned: \(assignee?.name ?? "—")").font(.system(size: 10)).foregroundStyle(NovaTheme.muted)
                    }
                    Spacer()
                    VStack(alignment: .trailing, spacing: 4) {
                        StatusPill(text: "\(task.hours)h", color: NovaTheme.blue)
                        Text(task.deadline).font(.system(size: 9)).foregroundStyle(NovaTheme.muted)
                    }
                }
            }
        }.buttonStyle(.plain)
    }
}

struct StatusPill: View {
    let text: String
    let color: Color
    var body: some View {
        Text(text).font(.system(size: 8, weight: .bold))
            .foregroundStyle(color).padding(.horizontal, 6).padding(.vertical, 3)
            .background(color.opacity(0.12), in: Capsule())
            .overlay(Capsule().stroke(color.opacity(0.2), lineWidth: 1))
    }
}

struct Avatar: View {
    let initials: String
    var size: CGFloat = 32
    var body: some View {
        Text(initials).font(.system(size: size * 0.32, weight: .bold))
            .foregroundStyle(.white)
            .frame(width: size, height: size)
            .background(LinearGradient(colors: [NovaTheme.blue.opacity(0.8), NovaTheme.lavenderBlue.opacity(0.65)], startPoint: .topLeading, endPoint: .bottomTrailing), in: Circle())
    }
}

struct BlueButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.foregroundStyle(.white)
            .background(LinearGradient(colors: [NovaTheme.blue, Color(red: 0.12, green: 0.48, blue: 0.82)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 10))
            .opacity(configuration.isPressed ? 0.8 : 1)
    }
}

struct SecondaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.font(.system(size: 11, weight: .semibold))
            .foregroundStyle(NovaTheme.cyan).padding(10)
            .background(NovaTheme.blue.opacity(0.10), in: RoundedRectangle(cornerRadius: 8))
    }
}

// MARK: - Detail Sheets & Transcript

struct ProjectDetailSheet: View {
    let project: WorkProject
    let tasks: [WorkTask]
    let allUsers: [User]
    let currentUser: User
    let onSelectTask: (WorkTask) -> Void
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack {
            NovaTheme.background.ignoresSafeArea()
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    HStack {
                        Text(project.name).font(.system(size: 20, weight: .bold)).foregroundStyle(.white)
                        Spacer()
                        Button("Close") { dismiss() }.buttonStyle(SecondaryButtonStyle())
                    }
                    GlassPanel {
                        Text("Client: \(project.client)").font(.system(size: 12, weight: .semibold)).foregroundStyle(NovaTheme.cyan)
                        Text(project.description).font(.system(size: 11)).foregroundStyle(NovaTheme.muted)
                        Text("Deadline: \(project.deadline)").font(.system(size: 11)).foregroundStyle(.white)
                    }
                    Text("Associated Tasks").font(.system(size: 14, weight: .semibold)).foregroundStyle(.white)
                    ForEach(tasks) { task in
                        TaskRow(task: task, project: project, assignee: allUsers.first(where: { $0.id == task.assigneeID })) {
                            dismiss()
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                                onSelectTask(task)
                            }
                        }
                    }
                }
                .padding(16)
            }
        }
    }
}

struct TaskDetailSheet: View {
    let task: WorkTask
    let project: WorkProject?
    let allUsers: [User]
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        ZStack {
            NovaTheme.background.ignoresSafeArea()
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Text("Task Details").font(.system(size: 18, weight: .bold)).foregroundStyle(.white)
                    Spacer()
                    Button("Close") { dismiss() }.buttonStyle(SecondaryButtonStyle())
                }
                GlassPanel {
                    Text(task.title).font(.system(size: 15, weight: .semibold)).foregroundStyle(.white)
                    Text(task.description).font(.system(size: 12)).foregroundStyle(NovaTheme.muted)
                    Divider().overlay(NovaTheme.border)
                    Text("Project: \(project?.name ?? "—")").font(.system(size: 11)).foregroundStyle(.white)
                    Text("Assigned to: \(allUsers.first(where: { $0.id == task.assigneeID })?.name ?? "—")").font(.system(size: 11)).foregroundStyle(.white)
                    Text("Effort: \(task.hours) hours").font(.system(size: 11)).foregroundStyle(.cyan)
                    Text("Deadline: \(task.deadline)").font(.system(size: 11)).foregroundStyle(.white)
                }
                Spacer()
            }
            .padding(16)
        }
    }
}

struct TranscriptSheet: View {
    @Binding var transcript: String
    @Binding var isProcessing: Bool
    let onGenerate: () -> Void
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var modelContext

    @State private var errorMessage: String?
    @State private var showErrorAlert = false

    var body: some View {
        ZStack {
            NovaTheme.background.ignoresSafeArea()
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    HStack {
                        Text("AI Transcript").font(.system(size: 18, weight: .bold)).foregroundStyle(.white)
                        Spacer()
                        Button("Close") { dismiss() }.buttonStyle(SecondaryButtonStyle())
                    }
                    Text("Paste meeting notes to auto-extract projects and tasks.").font(.system(size: 11)).foregroundStyle(NovaTheme.muted)
                    
                    TextEditor(text: $transcript)
                        .font(.system(size: 12))
                        .scrollContentBackground(.hidden)
                        .padding(8)
                        .background(NovaTheme.panel, in: RoundedRectangle(cornerRadius: 10))
                        .frame(minHeight: 200)

                    Button(action: {
                        guard !transcript.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
                        isProcessing = true
                        
                        let key = "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"
                        let ctx = modelContext
                        let notes = transcript
                        
                        Swift.Task {
                            do {
                                let aiService = AIService(apiKey: key)
                                _ = try await aiService.parseTranscript(notes, modelContext: ctx)
                                await MainActor.run {
                                    isProcessing = false
                                    onGenerate()
                                }
                            } catch {
                                await MainActor.run {
                                    isProcessing = false
                                    errorMessage = error.localizedDescription
                                    showErrorAlert = true
                                }
                            }
                        }
                    }) {
                        if isProcessing {
                            ProgressView().tint(.white).frame(maxWidth: .infinity)
                        } else {
                            Label("Generate Plan", systemImage: "sparkles")
                                .font(.system(size: 13, weight: .semibold))
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 10)
                        }
                    }
                    .buttonStyle(BlueButtonStyle())
                    .disabled(isProcessing || transcript.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
                .padding(16)
            }
        }
        .alert("AI Extraction Failed", isPresented: $showErrorAlert) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(errorMessage ?? "Unknown error occurred.")
        }
    }
}
