import Foundation
import SwiftData

public struct DemoSeedUser {
    let id: String
    let name: String
    let email: String
    let role: String
    let specialization: String
    let skills: [String]
}

public struct DemoSeedData {
    public static func makeDemoUsers() -> [User] {
        let rawUsers = [
            DemoSeedUser(id: "ADMIN", name: "Admin", email: "admin@novaworks.example", role: "ADMIN", specialization: "Company overview", skills: ["Company overview", "transcript creation"]),
            DemoSeedUser(id: "PM01", name: "Ayesha Khan", email: "ayesha@novaworks.example", role: "MANAGER", specialization: "Web PM", skills: ["Web projects", "client coordination"]),
            DemoSeedUser(id: "PM02", name: "Bilal Ahmed", email: "bilal@novaworks.example", role: "MANAGER", specialization: "Mobile PM", skills: ["Mobile projects", "delivery planning"]),
            DemoSeedUser(id: "PM03", name: "Hina Malik", email: "hina@novaworks.example", role: "MANAGER", specialization: "AI PM", skills: ["AI projects", "requirement review"]),
            DemoSeedUser(id: "DEV01", name: "Ali Raza", email: "ali@novaworks.example", role: "AGENT", specialization: "Full-Stack", skills: ["React", "frontend integration"]),
            DemoSeedUser(id: "DEV02", name: "Hamza Shah", email: "hamza@novaworks.example", role: "AGENT", specialization: "Full-Stack", skills: ["Node.js", "databases", "APIs"]),
            DemoSeedUser(id: "DEV03", name: "Sara Noor", email: "sara@novaworks.example", role: "AGENT", specialization: "App Developer", skills: ["Flutter", "mobile UI"]),
            DemoSeedUser(id: "DEV04", name: "Usman Tariq", email: "usman@novaworks.example", role: "AGENT", specialization: "App Developer", skills: ["Flutter", "integration", "testing"]),
            DemoSeedUser(id: "DEV05", name: "Zain Abbas", email: "zain@novaworks.example", role: "AGENT", specialization: "AI Developer", skills: ["LLMs", "extraction", "prompts"]),
            DemoSeedUser(id: "DEV06", name: "Maryam Asif", email: "maryam@novaworks.example", role: "AGENT", specialization: "AI Developer", skills: ["Retrieval", "document processing"])
        ]
        
        return rawUsers.map { u in
            User(id: u.id, name: u.name, email: u.email, role: u.role, specialization: u.specialization, skills: u.skills, password: "Demo123!")
        }
    }
}

@MainActor
public func seedDemoUsers(modelContext: ModelContext) {
    do {
        let descriptor = FetchDescriptor<User>()
        let existingUsers = try modelContext.fetch(descriptor)
        let existingUserIds = Set(existingUsers.map { $0.id })
        
        let demoUsers = DemoSeedData.makeDemoUsers()
        var insertedCount = 0
        
        for user in demoUsers {
            if !existingUserIds.contains(user.id) {
                modelContext.insert(user)
                insertedCount += 1
            }
        }
        
        if insertedCount > 0 {
            try modelContext.save()
            print("[NovaWorks] Successfully seeded \(insertedCount) demo user(s).")
        } else {
            print("[NovaWorks] All demo users already exist. No duplicates inserted.")
        }
    } catch {
        print("[NovaWorks] Failed to seed demo users: \(error.localizedDescription)")
    }
}
