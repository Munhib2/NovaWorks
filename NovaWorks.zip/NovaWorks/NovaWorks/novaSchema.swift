import Foundation
import SwiftData

public struct NovaWorksSchema {
    public static let schema = Schema([
        User.self,
        Project.self,
        Task.self
    ])

    public static func makeContainer(isStoredInMemoryOnly: Bool = false) -> ModelContainer {
        let configuration = ModelConfiguration(schema: schema, isStoredInMemoryOnly: isStoredInMemoryOnly)
        do {
            return try ModelContainer(for: schema, configurations: [configuration])
        } catch {
            fatalError("Could not create ModelContainer: \(error)")
        }
    }
    
    @MainActor
    public static var previewContainer: ModelContainer = {
        let container = makeContainer(isStoredInMemoryOnly: true)
        seedDemoUsers(modelContext: container.mainContext)
        return container
    }()
}
